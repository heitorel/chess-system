package boardgame;

public class BoardException extends RuntimeException{

    public BoardException(String message) {
        super(message);
    }
}
